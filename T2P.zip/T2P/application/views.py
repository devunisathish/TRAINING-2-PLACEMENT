from django.shortcuts import render,HttpResponse
from .models import Trainingregister 
from .models import Placementregister

# Create your views here.
def index(request):
    return render(request,'index.html')

def training(request):
    training= Trainingregister.objects.all()
    return render(request,'training.html',{'training':training})

def placements(request):
    placements= Placementregister.objects.all()
    return render(request,'placements.html',{'placements':placements})
    

def login(request):
    return render(request,'login.html')

def placement(request):
    if request.method=="POST":
        name=request.POST.get("name")
        job=request.POST.get("job")
        location=request.POST.get("location")
        study=request.POST.get("study")
        experience=request.POST.get("experience")
        salary=request.POST.get("salary")
        startdate=request.POST.get("startdate")
        link=request.POST.get("link")


        #print(name,father,number,email,item,address,location) #this line for print the data into terminal
        
        query=Placementregister(name=name,job=job,study=study,location=location,experience=experience,salary=salary,startdate=startdate,link=link)
        query.save()
        return HttpResponse("Response as been recorded")

    return render(request,'placement.html')


def trainings(request):
    if request.method=="POST":
        name=request.POST.get("name")
        course=request.POST.get("course")
        study=request.POST.get("study")
        age=request.POST.get("age")
        seats=request.POST.get("seats")
        duration=request.POST.get("duration")
        location=request.POST.get("location")
        date=request.POST.get("date")
        link=request.POST.get("link")


        #print(name,father,number,email,item,address,location) #this line for print the data into terminal
        
        query=Trainingregister(name=name,course=course,study=study,age=age,seats=seats,duration=duration,location=location,date=date,link=link)
        query.save()
        return HttpResponse("Response as been recorded")

    return render(request,'trainings.html')

def cart(request):
    return render(request,'cart.html')

def query(request):
    return render(request,'query.html')

def about(request):
    return render(request,'about.html')

def drive(request):
    return render(request,'drive.html')

def contact(request):
    return render(request,'contact.html')