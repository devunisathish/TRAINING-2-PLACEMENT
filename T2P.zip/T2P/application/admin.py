from django.contrib import admin

from .models import Trainingregister
from .models import Placementregister
# Register your models here.

admin.site.register(Trainingregister)
admin.site.register(Placementregister)

