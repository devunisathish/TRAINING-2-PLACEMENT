from django.urls import path, include
from application import views
from django.contrib import admin


urlpatterns = [
    path('', views.index,name='index'),
    path('training',views.training,name='training'),
    path('placements',views.placements,name='placements'),
    path('login',views.login,name='login'),
    path('placement',views.placement,name='placement'),
    path('trainings',views.trainings,name='trainings'),
    path('cart',views.cart,name='cart'),
    path('query',views.query,name='query'),
    path('about',views.about,name='about'),
    path('drive',views.drive,name='drive'),
    path('contact',views.contact,name='contact'),
]