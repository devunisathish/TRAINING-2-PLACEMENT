from django.db import models

# Create your models here.

class Trainingregister(models.Model):
    sno=models.AutoField(primary_key=True)
    name=models.CharField(max_length=30)
    course=models.CharField(max_length=30)
    study=models.CharField(max_length=40)
    age=models.CharField(max_length=10)
    seats=models.IntegerField()
    duration=models.CharField(max_length=50)
    location=models.CharField(max_length=60)
    date=models.DateField()
    link=models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Placementregister(models.Model):
    sno=models.AutoField(primary_key=True)
    name=models.CharField(max_length=30)
    job=models.CharField(max_length=50)
    location=models.CharField(max_length=100)
    study=models.CharField(max_length=50)
    experience=models.CharField(max_length=60)
    salary=models.IntegerField()
    startdate=models.CharField(max_length=50)
    link=models.CharField(max_length=100)
    

    def __str__(self):
        return self.name
    



